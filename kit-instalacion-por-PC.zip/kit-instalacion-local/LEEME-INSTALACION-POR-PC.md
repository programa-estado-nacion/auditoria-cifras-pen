# Kit de instalación por PC — Complemento "Auditoría de Cifras"

Sirve para que un funcionario vaya a cada computadora y deje el complemento instalado
en Word, sin usar el Centro de administración. El script registra el "catálogo de
confianza" por el usuario (no requiere permisos de administrador).

## Requisito previo (una sola vez)

Word solo confía en catálogos que estén en una **carpeta de red** (ruta `\\servidor\carpeta`).
Por eso, antes de recorrer las PC:

1. Coloque el archivo `manifest.xml` (incluido en este kit) en una carpeta de red
   accesible desde las computadoras de los usuarios (por ejemplo `\\servidor\complementos`).
2. Abra `Instalar-AuditoriaPEN.bat` con el Bloc de notas y edite **una sola línea**, la que dice:
   `set "CATALOGO=\\SERVIDOR\CarpetaCompartida"`
   Ponga ahí la ruta real de esa carpeta de red. Guarde. Use ese mismo .bat en todas las PC.

## En cada computadora (rápido)

1. Doble clic en **`Instalar-AuditoriaPEN.bat`**.
2. Cierre y vuelva a abrir Word.
3. En Word: **Inicio → Complementos → Más complementos → pestaña CARPETA COMPARTIDA**,
   elija **"Auditoría de Cifras PEN"** y pulse **Agregar**.

Listo: queda el botón del complemento en Word.

## Para quitarlo

Doble clic en **`Desinstalar-AuditoriaPEN.bat`** y reinicie Word.

## Requisitos y notas

- Word de Microsoft 365 (escritorio), Windows.
- La computadora debe tener acceso a la carpeta de red y a internet; la interfaz del
  complemento se sirve por HTTPS desde GitHub Pages.
- El script escribe solo en el perfil del usuario actual; no requiere administrador.
- **Pruébelo primero en UNA computadora** antes de recorrer todas, para confirmar que
  la carpeta de red y Word responden como se espera en su entorno.

## Alternativa recomendada

Si el objetivo es llegar a muchas personas, el **despliegue centralizado** por el área de
TI (Centro de administración de Microsoft 365 → Aplicaciones integradas) es más simple y
confiable: se hace una sola vez y a todos les aparece el complemento, sin recorrer PC por PC.

@echo off
setlocal EnableExtensions
chcp 65001 >nul
title Instalar complemento Auditoria de Cifras PEN

REM ============================================================
REM  EDITE ESTA LINEA UNA SOLA VEZ con la carpeta de red que
REM  contiene el archivo manifest.xml (ruta tipo \\servidor\carpeta).
set "CATALOGO=\\SERVIDOR\CarpetaCompartida"
REM ============================================================

set "GUID={F9B45EFA-48C7-4EC0-8919-E2D858BD7A36}"
set "BASE=HKCU\Software\Microsoft\Office\16.0\WEF\TrustedCatalogs\%GUID%"

echo Registrando catalogo de complementos: %CATALOGO%
reg add "%BASE%" /v Id    /t REG_SZ    /d "%GUID%"     /f >nul
reg add "%BASE%" /v Url   /t REG_SZ    /d "%CATALOGO%" /f >nul
reg add "%BASE%" /v Flags /t REG_DWORD /d 1            /f >nul

if %errorlevel%==0 (
  echo.
  echo  LISTO. El catalogo quedo registrado en esta PC.
  echo.
  echo  Ahora en Word:
  echo   1^) Cierre y vuelva a abrir Word.
  echo   2^) Inicio ^> Complementos ^> Mas complementos ^> pestana CARPETA COMPARTIDA.
  echo   3^) Elija "Auditoria de Cifras PEN" y pulse Agregar.
) else (
  echo  Ocurrio un error al registrar el catalogo.
)
echo.
pause
